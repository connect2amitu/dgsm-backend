<div class="page-header page-header-inverse">
	<div class="page-header-content">
		<div class="page-title">
			<h5>
				<i class="icon-circle-left2 position-left"></i>
				<span class="text-semibold">Page Header</span> - Inverse
				<small class="display-block">Dark background color</small>
			</h5>
		</div>
	</div>
	<div class="breadcrumb-line">
		<ul class="breadcrumb">
			<li><a href="<?=base_url()?>"><i class="icon-home2 position-left"></i> Home</a></li>
			<li class="active">Bhajan</li>
		</ul>
	</div>
</div>

<div class="content">
	<h1>Bhajan</h1>
</div>
